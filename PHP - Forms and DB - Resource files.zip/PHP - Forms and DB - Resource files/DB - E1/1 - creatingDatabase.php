<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "my_db";

    //Establishing a connection to the database
	$con = new mysqli($servername,$username,$password);

    if ($con -> connect_errno) {
		echo "Failed to connect to MySQL: " . $con -> connect_error;
		exit();
	}
    
    //Creating a database
    $sql_create_db = "CREATE DATABASE IF NOT EXISTS my_db";

    if ($con->query($sql_create_db) === TRUE) {
		echo "Database : $dbname created successfully";
	} else {
		echo "Error creating database: " . $con->error;
	}
        
    //closing connection
    $con->close();

?>