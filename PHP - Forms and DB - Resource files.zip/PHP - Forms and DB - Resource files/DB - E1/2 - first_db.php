<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "my_db";

   //new connection to the db - OOP
	$con = new mysqli($servername,$username,$password,$dbname);
	
	if ($con -> connect_errno) {
		echo "Failed to connect to MySQL: " . $con -> connect_error;
		exit();
	}
     
	 echo "Connected to DB successfully";
	 
    //closing connection
    $con->close();

?>