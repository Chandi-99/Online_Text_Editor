<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "my_db";

   //new connection to the db - OOP
	$con = new mysqli($servername,$username,$password,$dbname);
	
	if ($con -> connect_errno) {
		echo "Failed to connect to MySQL: " . $con -> connect_error;
		exit();
	}
        
    //Createing table
    $sql_create_table = "CREATE TABLE Persons
                        (   
                            ID int NOT NULL AUTO_INCREMENT,
                            FirstName varchar(15) ,
                            LastName varchar(15),
                            Age int,
                            PRIMARY KEY (ID)
                        )";
    
    // Executing the query
    if ($con->query($sql_create_table) === TRUE) {
		echo "Table created successfully";
	} else {
		echo "Error creating database: " . $con->error;
	}
        
    //closing connection
    $con->close();
?>