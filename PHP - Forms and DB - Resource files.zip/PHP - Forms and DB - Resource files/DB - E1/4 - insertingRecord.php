<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "my_db";

   	$con = new mysqli($servername,$username,$password,$dbname);
	
	if ($con -> connect_errno) {
		echo "Failed to connect to MySQL: " . $con -> connect_error;
		exit();
	}
    
    // Inserting a record
    $sql_insert_record = "INSERT INTO Persons VALUES(0,'Hansi','Udapola',24)";
    
    // Execute query
	if ($con->query($sql_insert_record) === TRUE) {
		$last_id = $con->insert_id;
		echo "Successfully inserted a record with ID = $last_id <br/>";
	}else {
		echo "Error: " . $sql_insert_record . "<br/>" . $con->error;
	}
	
	$sql_insert_record = "INSERT INTO Persons VALUES(0,'Amal','Perera',30)";
	if ($con->query($sql_insert_record) === TRUE) {
		$last_id = $con->insert_id;
		echo "Successfully inserted another record with ID = $last_id <br/>";
	}else {
		echo "<br/>Error: " . $sql_insert_record . "<br/>" . $con->error;
	}	
	
    //closing connection
    $con->close();
?>