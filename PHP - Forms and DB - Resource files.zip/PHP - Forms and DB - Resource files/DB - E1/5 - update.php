<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "my_db";

   
	$con = new mysqli($servername,$username,$password,$dbname);
	
	if ($con -> connect_errno) {
		echo "Failed to connect to MySQL: " . $con -> connect_error;
		exit();
	}
    
    $sql_update = "UPDATE Persons SET Age = '28' WHERE firstname = 'Hansi' AND lastname = 'Udapola'";
    
    // Executing query
    if ($con->query($sql_update) === TRUE) {
		echo "Record Updated Successfully";
	} else {
		echo "Error creating database: " . $con->error;
	}

    // Closing connection
    $con->close();
?>