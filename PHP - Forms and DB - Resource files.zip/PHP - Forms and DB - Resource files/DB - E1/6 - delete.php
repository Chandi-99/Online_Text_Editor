<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "my_db";

   
	$con = new mysqli($servername,$username,$password,$dbname);
	
	if ($con -> connect_errno) {
		echo "Failed to connect to MySQL: " . $con -> connect_error;
		exit();
	}
    
    $sql_delete = "DELETE FROM Persons WHERE LastName='Perera'";
    
    // Executing query
    if ($con->query($sql_delete) === TRUE) {
		echo "Records having LastName='Perera' Successfully Deleted!";
		echo "Deleted rows: " .  $con -> affected_rows;
	} else {
		echo "Error creating database: " . $con->error;
	}

    // Closing connection
    $con->close(); 
?>