<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "my_db";

   
	$con = new mysqli($servername,$username,$password,$dbname);
	
	if ($con -> connect_errno) {
		echo "Failed to connect to MySQL: " . $con -> connect_error;
		exit();
	}
    
    $sql_select = "SELECT firstname,lastname, Age FROM Persons";

    // Execute query
    $result = $con->query($sql_select);
    
    // Displaying all records By Fetching a row as a numeric array
    echo "<h3>Displaying all records by fetching a row as an associative array</h3>";
		if ($result->num_rows > 0) {
			// output data of each row
			while($row = $result->fetch_assoc()) {
				echo "Name: " . $row["firstname"]. " " . $row["lastname"]. " Age: " . $row["Age"] . "<br/>";
			}
		} else {
			echo "RECORDS NOT FOUND!!!";
		}

	echo "<p> No. of rows: " .  $con -> affected_rows."</p><br/>";
	
	// Execute query
    $result = $con->query($sql_select);
	
    // Displaying all records By Fetching a row as an associative array:
	echo "<h3>Displaying all records by fetching a row as a numeric array </h3>";
    
    if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_array(MYSQLI_NUM)) {
			echo "Name: " . $row[0]. " " . $row[1]. " Age: " . $row[2] . "<br/>";
		}
	} else {
		echo "RECORDS NOT FOUND!!!";
	}

	echo "<p> No. of rows: " .  $con -> affected_rows."</p><br/>";
    
	// Free result set
	$result -> free_result();

	//Closing connection
	$con -> close();
?>