<html>
	<head>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	</head>
	<body>
		<div class="container">
		<?php
			$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname = "my_db";

		   
			$con = new mysqli($servername,$username,$password,$dbname);
			
			if ($con -> connect_errno) {
				echo "Failed to connect to MySQL: " . $con -> connect_error;
				exit();
			}
			
			$sql_select = "SELECT * FROM Persons ORDER BY age";

			// Execute query
			$result = $con->query($sql_select);
			
			// Displaying all records in a table
			echo "<h3>Displaying all records in a table</h3>";
				if ($result->num_rows > 0) {
					$tabletxt =  "<table class='table table-striped table-hover'>
								<tr class='table-info'>
								<th scope='col'>#</th>
								<th scope='col'>Firstname</th>
								<th scope='col'>Lastname</th>
								<th scope='col'>Age</th>
								</tr>";
					while($row = $result->fetch_array(MYSQLI_NUM)) {
						//building table rows
						$tabletxt .= "<tr scope='row'>";
						$tabletxt .= "<td>" . $row[0] . "</td>";
						$tabletxt .= "<td>" . $row[1] . "</td>";
						$tabletxt .= "<td>" . $row[2] . "</td>";
						$tabletxt .= "<td>" . $row[3] . "</td>";
						$tabletxt .= "</tr>";
					}					
					$tabletxt .= "</table>";
					echo $tabletxt;
				} else {
					echo "<p>RECORDS NOT FOUND!!!</p>";
				}

			echo "<p> No. of rows: " .  $con -> affected_rows."</p><br/>";
			
			// Free result set
			$result -> free_result();

			//Closing connection
			$con -> close();
		?>
		</div>
	</body>
</html>