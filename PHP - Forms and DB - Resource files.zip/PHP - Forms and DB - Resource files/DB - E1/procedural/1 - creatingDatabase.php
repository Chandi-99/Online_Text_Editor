<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "my_db";

    //Establishing a connection to the database
    $con = mysqli_connect($servername,$username,$password);

    if (!$con){
        
        die('Could not connect: ' . mysqli_error($con));
        
    }
    
    //Creating a database
    $sql_create_db = "CREATE DATABASE my_db";

    if (mysqli_query($con, $sql_create_db)){
        
        echo "Database created!</br>";
    
    }else{
        
        die("Error creating database: " . mysqli_error($con));                 
    
    }
        
    //closing connection
    mysqli_close($con);

?>