<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "my_db";

    //Establishing a connection to the database
    $con = mysqli_connect($servername,$username,$password);

    if (!$con){
        
        die('Could not connect: ' . mysql_error());
        
    }
    
    //Selecting database
    mysqli_select_db($con, $dbname);
    
    //Createing table
    $sql_create_table = "CREATE TABLE Persons
                        (   
                            ID int NOT NULL AUTO_INCREMENT,
                            FirstName varchar(15) ,
                            LastName varchar(15),
                            Age int,
                            PRIMARY KEY (ID)
                        )";
    
    // Executing the query
    if(mysqli_query($con, $sql_create_table))
        
        echo "Successfully created a table! </br>";

    else
        
        die("Error occured while creating table!". mysqli_error($con));
        
    //closing connection
    mysqli_close($con);
?>