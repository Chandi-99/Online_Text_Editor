<?php
	$servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "my_db";

	//Establishing a connection to the database
    $con = mysqli_connect($servername,$username,$password);

	if (!$con){
        die('Could not connect: ' . mysql_error());  
    }
	
	//Selecting database
    mysqli_select_db($con, $dbname);
	
	// Inserting a record
    $sql_insert_record = "INSERT INTO Persons VALUES(0,'Hansi','Udapola',24)";
    $sql_insert_record_id = "SELECT LAST_INSERT_ID()";
	
    if(mysqli_query($con, $sql_insert_record)){
		$result = mysqli_query($con, $sql_insert_record_id);
		$row = mysqli_fetch_array($result, MYSQLI_NUM);
        if($row)
			echo "Successfully inserted a record with ID =". $row[0] ."</br>";
    }else die( "Error occured while inserting!". mysqli_error($con));
    
	$sql_insert_record = "INSERT INTO Persons VALUES(0,'Amal','Perera',30)";	
	// Execute 2nd query
    if(mysqli_query($con, $sql_insert_record)){
		$result = mysqli_query($con, $sql_insert_record_id);
		$row = mysqli_fetch_array($result, MYSQLI_NUM);
        if($row)
			echo "Successfully inserted a record with ID =". $row[0] ."</br>";
    }else die( "Error occured while inserting!". mysqli_error($con));
	



?>