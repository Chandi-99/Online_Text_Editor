<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "my_db";

    $con = mysqli_connect($servername, $username, $password); 

    if (!$con) { 
        
        die('Could not connect: ' . mysql_error()); 
    
    } 

    //Selecting database
    mysqli_select_db($con, $dbname);
    
    $sql_update = "UPDATE Persons SET Age = '27' WHERE firstname = 'Hansi' AND lastname = 'Udapola'";
    
    // Executing query
    if(mysqli_query($con, $sql_update))
        
        echo "Successfully updated!";
    
    else
        die( "Error occured while updating!". mysqli_error($con));

    // Closing connection
    mysqli_close($con); 
?>