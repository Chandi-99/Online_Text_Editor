<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "my_db";

    $con = mysqli_connect($servername, $username, $password); 

    if (!$con) { 
        
        die('Could not connect: ' . mysql_error()); 
    
    } 

    //Selecting database
    mysqli_select_db($con, $dbname);
    
    $sql_delete = "DELETE FROM Persons WHERE LastName='Perera'";
    
    // Executing query
    if(mysqli_query($con, $sql_delete))
        
        echo "Successfully deleted!";
    
    else
        
        die( "Error occured while deleting!". mysqli_error($con));

    // Closing connection
    mysqli_close($con); 
?>