<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "my_db";

    //Establishing a connection to the database
    $con = mysqli_connect($servername,$username,$password);

    if (!$con){
        
        die('Could not connect! Error: ' . mysql_error());
        
    }

    //Selecting database
    mysqli_select_db($con, $dbname);
    
    $sql_select = "SELECT firstname,lastname FROM Persons";

    // Execute query
    $result = mysqli_query($con, $sql_select);
    
    // Displaying all records
    //By Fetching a row as a numeric array
    echo "Displaying all records by fetching a row as a numeric array <br/>";
    while($row = mysqli_fetch_array($result, MYSQLI_NUM)){
        
        echo $row[0]. " " . $row[1];
        echo "<br/>";
    }

    // Displaying all records
    //By Fetching a row as an associative array:

    echo "Displaying all records by fetching a row as an associative array<br/>";
    $result = mysqli_query($con, $sql_select);

    while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
        
        echo $row['firstname']. " " . $row['lastname'];
        echo "<br/>";
    }

    // Free result set
    mysqli_free_result($result);
     
    //Closing connection
    mysqli_close($con);

?>