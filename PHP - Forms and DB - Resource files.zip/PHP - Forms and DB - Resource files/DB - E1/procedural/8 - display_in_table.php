<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "my_db";

    //Establishing a connection to the database
    $con = mysqli_connect($servername,$username,$password);

    if (!$con){
        
        die('Could not connect! Error: ' . mysql_error());
        
    }

    //Selecting database
    mysqli_select_db($con, $dbname);
    
    $sql_select = "SELECT * FROM Persons ORDER BY age";

    // Execute query
    $result = mysqli_query($con, $sql_select);
    
    // Displaying all records in a table
    //By Fetching a row as a numeric array
    echo "  <table border='1'>
            <tr>
            <th>ID</th>
            <th>Firstname</th>
            <th>Lastname</th>
            <th>Age</th>
            </tr>";

    while($row = mysqli_fetch_array($result, MYSQLI_NUM)){
        
        echo "<tr>";
        echo "<td>" . $row[0] . "</td>";
        echo "<td>" . $row[1] . "</td>";
        echo "<td>" . $row[2] . "</td>";
        echo "<td>" . $row[3] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Free result set
    mysqli_free_result($result);
     
    // Closing connection
    mysqli_close($con);

?>