<?php
$stlist = ["ST/001","ST/003","ST/010"];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if(isset($_POST["stid"]) && isset($_POST["stname"]) && isset($_POST["styear"]) && isset($_POST["gender"])){
		
		if(in_array($_POST["stid"],$stlist)){
			echo "-1";
			return;
		}
		
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "streg";

   
		$con = new mysqli($servername,$username,$password,$dbname);
	
		if ($con -> connect_errno) {
			echo "0";
			//echo "Failed to connect to MySQL: " . $con -> connect_error;
			return;
		}
		
		//Check the students is already registered or not
		$sql = "SELECT * FROM tblstudents WHERE SID = '". $_POST["stid"]."'";
		$result = $con->query($sql);
		
		if ($result->num_rows > 0) {
			echo "-2";
		} else { //Else Insert Data into DB
			$sql = "INSERT INTO tblstudents VALUES(?,?,?,?)";
			$stmt = $con->prepare($sql);
			$stmt->bind_param("ssis", $sid, $stname, $styear, $gender);
			
			// set parameters and execute
			$sid = $_POST["stid"];
			$stname = $_POST["stname"];
			$styear = $_POST["styear"];
			$gender = $_POST["gender"];
			$stmt->execute();
			
			echo "1";
			$stmt->close();
		}
		
		$con->close();
	}
	
}
?>