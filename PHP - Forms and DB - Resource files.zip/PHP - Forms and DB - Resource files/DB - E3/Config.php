<?php

// database settings
define('HOST',"localhost");
define('USERNAME',"root");
define('PASSWORD',"");
define('DATABASE_NAME',"streg");

?>
