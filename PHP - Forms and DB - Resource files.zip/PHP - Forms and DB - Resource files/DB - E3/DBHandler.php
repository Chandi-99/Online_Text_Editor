<?php
	include_once './DbConnect.php';
	
	//create a new dbconnection object
	$db = new DbConnect();
		
	//connect to the DB
	$conn = $db->getConnection();

	if(isset($_GET['students'])){
		$sql = "SELECT * FROM tblstudents";
		$result = $conn->query($sql);
		$data = array();
		if ($result->num_rows > 0) {
			
			while($row = $result->fetch_assoc()) {
				$d = array();
				$d['SID'] = $row['SID']."";
				array_push($data,$d);
			}
			
			echo "".json_encode($data);
		}

	// Free result set
	$result -> free_result();		
	
	}
	
	
	if(isset($_GET['id'])){
		$sql = "SELECT * FROM tblstudents WHERE SID='".$_GET['id']."'";
		$result = $conn->query($sql);
		$data = array();
		if ($result->num_rows > 0) {
			if($row = $result->fetch_assoc()){ 
				$data['SID'] = $row['SID']."";
				$data['StName'] = $row['StName']."";
				$data['StYear'] = $row['StYear']."";
				$data['Gender'] = $row['Gender']."";
			}
			
			echo "".json_encode($data);
		}

	// Free result set
	$result -> free_result();		
	
	}
	
	if(isset($_POST["stid"]) && isset($_POST["stname"]) && isset($_POST["styear"]) && isset($_POST["gender"])){
		$stname = $_POST["stname"];
		$yr = $_POST["styear"];
		$gen = $_POST["gender"];
		$sid = $_POST["stid"];
		
		$sql = "UPDATE tblstudents SET StName = '$stname' , StYear = $yr , Gender = '$gen'  WHERE SID = '$sid'";
		
		if ($conn->query($sql) === TRUE) {
			echo "Record Updated Successfully";
		} else {
			echo "Error creating database: " . $con->error;
		}
	}
?>