<?php
//link the external php file
include_once './Config.php';

//PHP - OOP
class DbConnect {
    
    private $conn;

    // constructor
    function __construct() {
        // connecting to database
        $this->connect();
    }

    // destructor
    function __destruct() {
        // closing db connection
        $this->close();
    }
	
	function getConnection(){
		return $this->conn;
	}

    /**
     * Establishing database connection
     * @return database handler
     */
    function connect() {        
		include_once dirname(__FILE__) . '/Config.php';
        
        // Connecting to mysql database
        $this->conn = new mysqli(HOST, USERNAME, PASSWORD, DATABASE_NAME);
		if ($this-> conn -> connect_errno) {
			echo "Failed to connect to MySQL: " . $this->conn -> connect_error;
			exit();
		}
		
		//set character set to utf-8
		$this->conn -> set_charset("utf8");
        
        // returing connection resource
        return $this->conn; 
    }

    /**
     * Closing database connection
     */
    function close() {
        // closing db connection
		$this->conn->close();
    }
	
	function executeQuery($sql=""){
		if ($this->conn->query($sql) === TRUE) {
			return $this->conn -> affected_rows;
		}else {
			echo "". $this->conn->error;
		}
	}
}

?>
