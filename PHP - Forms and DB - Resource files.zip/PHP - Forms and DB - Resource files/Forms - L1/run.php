<html>
    <head>
        <title>FormHandling</title>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
		<style>
			*{
				text-align:center;
			}
			
			#div1{
				padding: 20px;
				background-color:#e3c7f0;
				width:50%;
				margin:auto;
			}
		</style>
    </head>
    <body>
        <?php
		if ($_SERVER["REQUEST_METHOD"] == "GET") {
			echo "<div id='div1'>";
            echo "HI! <h1>". $_GET["uname"]."</h1>";
            echo "<p class='lead'> Your email is " . $_GET["email"] . "</h2>";
			echo "</div>";
		}
        ?>
    </body>
</html>
