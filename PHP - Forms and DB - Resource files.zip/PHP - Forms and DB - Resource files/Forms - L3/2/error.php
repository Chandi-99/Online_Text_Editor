<?php
	echo "<h1> Error Page </h1>";
?>