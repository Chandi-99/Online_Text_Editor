<?php
	echo "<h1> This is the HOME page </h1>";
?>