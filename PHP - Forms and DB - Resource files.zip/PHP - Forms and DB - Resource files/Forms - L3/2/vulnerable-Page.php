<?php
//someone enter page=http://localhost:8080/hacksite/unauthorizedPage.php
//someone enter page=https://cal.kln.ac.lk/login/index.php
	if(isset($_GET['page']))
		include $_GET['page'];
	else
	 include 'index.html';
?>