<?php
$stlist = ["ST/001","ST/003","ST/010"];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$data = array();
	if(isset($_POST["stid"]) && isset($_POST["stname"]) && isset($_POST["styear"]) && isset($_POST["gender"])){
		
		if(in_array($_POST["stid"],$stlist)){
			echo "0";
			return;
		}
		
		$data['StID'] = $_POST["stid"];
		$data['StName'] = $_POST["stname"];
		$data['year'] = "YEAR - " . $_POST["styear"];
		$data['gender']= ($_POST["gender"]=="F") ? "Female" : "Male";
		
		echo "".json_encode($data);
	}
	
}
?>