<html>
    <head>
        <title>Exercise 2</title>
		<!-- CSS Bootstrap -->
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
		<style>
			div{
				padding:10px;
				}
				
			div.main{
				background-color:#b797c2;
			}
			
			div.msg{
				background-color:#b0d9b8;
				margin-top:10px;
			}
			
			button[type="submit"]{
				background-color:#b34680;
				border:1px solid #b34680;
			}
			
			button[type="submit"]:hover{
				background-color:#691340;
				border:1px solid #691340;
			}
			
			button[type="submit"]:active{
				background-color:#691340;
				border:1px solid #691340;
			}
			
			.form-control:focus, .form-select:focus, form-check:checked{
				 border-color: #b34680;
				 box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(105, 19, 64, 0.6);
			}
			
			
		
		</style>
    </head>
    <body>
	<div class="container main">
	<h1 class="display-6">Student Registration Form</h1>
		<form method="post"  action="self.php">
			<div class="row">
				<div class="col">
					<label for="stid" class="form-label">Student ID: </label>
					<input type="text" class="form-control" id="stid" name="stid" required>
				</div>
				<div class="col">
					<label for="stname" class="form-label">Student Name:</label>
					<input type="text" class="form-control" id="stname" name="stname" required>
				</div>
			</div>
			<div class="row">
				<div class="col">
					<label for="styear" class="form-label">Please select the year.</label><br/>
					<div class="form-check form-check-inline">
					  <input class="form-check-input" type="radio" name="styear" id="styear1" value="1">
					  <label class="form-check-label" for="styear1">1<sup>st</sup> Year</label>
					</div>
					<div class="form-check form-check-inline">
					  <input class="form-check-input" type="radio" name="styear" id="styear2" value="2">
					  <label class="form-check-label" for="styear2">2<sup>nd</sup> Year</label>
					</div>
					<div class="form-check form-check-inline">
					  <input class="form-check-input" type="radio" name="styear" id="styear3" value="3">
					  <label class="form-check-label" for="styear3">3<sup>rd</sup> Year</label>
					</div>
					<div class="form-check form-check-inline">
					  <input class="form-check-input" type="radio" name="styear" id="styear4" value="4">
					  <label class="form-check-label" for="styear4">4<sup>th</sup> Year</label>
					</div>
				</div>
				<div class="col">
					<label for="gender" class="form-label">Gender:</label><br/>
					<select class="form-select" aria-label="Default select example" name="gender">
					  <option value="M" selected>Male</option>
					  <option value="F">Female</option>
					</select>
				</div>
				
			</div>
			<button type="submit" class="btn btn-primary">SUBMIT</button>
		</form>
	</div>
	<div class="container msg">
		<?php
			$stlist = ["ST/001","ST/003","ST/010"];

			if ($_SERVER["REQUEST_METHOD"] == "POST") {
				$data = array();
				if(isset($_POST["stid"]) && isset($_POST["stname"]) && isset($_POST["styear"]) && 	isset($_POST["gender"])){
						if(in_array($_POST["stid"],$stlist)){
							echo "0";
							exit();
						}
					
					$data['StID'] = $_POST["stid"];
					$data['StName'] = $_POST["stname"];
					$data['year'] = "YEAR - " . $_POST["styear"];
					$data['gender']= ($_POST["gender"]=="F") ? "Female" : "Male";
				
					echo json_encode($data);
				}
			}
		?>
	
	</div>
    </body>
</html>